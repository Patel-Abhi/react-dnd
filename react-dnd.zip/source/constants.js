export default {
  SNACK: 'snack'
};

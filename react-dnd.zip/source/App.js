import React from 'react';
import { render } from 'react-dom';
import Container from './Container';

render(<Container />, document.getElementById('root'));
